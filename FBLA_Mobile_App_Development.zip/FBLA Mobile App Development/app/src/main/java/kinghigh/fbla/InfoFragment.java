package kinghigh.fbla;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class InfoFragment extends Fragment {


    public InfoFragment() {

    }

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_info, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("KHS FBLA");
        return view;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView textView = (TextView) getView().findViewById(R.id.web_link);
        TextView textView2 = (TextView) getView().findViewById(R.id.web_link2);

        String text = "FBLA-PBL Official Website: https://www.fbla-pbl.org/";
        String text2= "FBLA-PBL Florida Chapter Website: https://www.floridafbla-pbl.com/";

        SpannableString ss = new SpannableString(text);
        SpannableString ss2 = new SpannableString(text2);

        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.fbla-pbl.org"));
                startActivity(browerIntent);
            }
        };
        ClickableSpan clickableSpan2 = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.floridafbla-pbl.com/"));
                startActivity(browerIntent);
            }
        };

        ss.setSpan(clickableSpan1, 27, 52, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss2.setSpan(clickableSpan2, 34, 66, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());

        textView2.setText(ss2);
        textView2.setMovementMethod(LinkMovementMethod.getInstance());
    }
}

