package kinghigh.fbla;

import android.content.Context;
import android.graphics.Color;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class CalenderFragment extends Fragment {

    private static List<CalendarEvent> calendarEvents = null;

    public CalenderFragment()
    {
    }

    private ListView listView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_calender, container, false);
        final ActionBar actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(false);

        CompactCalendarView compactCalendar = (CompactCalendarView) view.findViewById(R.id.compactcalendar_view);
        compactCalendar.setUseThreeLetterAbbreviation(true);
        actionBar.setTitle(new SimpleDateFormat("MMM YYYY").format(compactCalendar.getFirstDayOfCurrentMonth()));

        loadCalendarEvents(getActivity().getApplicationContext(), compactCalendar);

        List<String> eventsInMonth = filterEventsByMonthAndYear(compactCalendar.getFirstDayOfCurrentMonth());

        listView = (ListView)view.findViewById(R.id.listview);
        ArrayAdapter arrayAdapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1, eventsInMonth);
        listView.setAdapter(arrayAdapter);

        compactCalendar.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                List<String> eventsInMonth = filterEventsByDate(dateClicked);

                ArrayAdapter arrayAdapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1, eventsInMonth);
                listView.setAdapter(arrayAdapter);
            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                actionBar.setTitle(new SimpleDateFormat("MMM YYYY").format(firstDayOfNewMonth));

                List<String> eventsInMonth = filterEventsByMonthAndYear(firstDayOfNewMonth);
                ArrayAdapter arrayAdapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1, eventsInMonth);
                listView.setAdapter(arrayAdapter);
            }

        });

        return view;
    }

    private List<String> filterEventsByDate(Date selectedDate) {
        List<String> result = new ArrayList<>();

        if(selectedDate != null)
        {
            for(CalendarEvent calEvent : calendarEvents)
            {
                if(calEvent.getEventDate().equals(selectedDate))
                {
                    result.add(new SimpleDateFormat("MMM dd").format(calEvent.getEventDate()) + "  " + calEvent.getEventDescription() );
                }
            }
        }

        if(result.size() == 0)
        {
            result.add("No events exists for this day");
        }
        return result;
    }

    private List<String> filterEventsByMonthAndYear(Date firstDayOfCurrentMonth) {
        List<String> result = new ArrayList<>();
        if(firstDayOfCurrentMonth != null)
        {
            Calendar cal = Calendar.getInstance();
            cal.setTime(firstDayOfCurrentMonth);
            int filterMonth = cal.get(Calendar.MONTH);
            int filterYear = cal.get(Calendar.YEAR);

            for(CalendarEvent calEvent : calendarEvents)
            {
                cal.setTime(calEvent.getEventDate());
                int month = cal.get(Calendar.MONTH);
                int year = cal.get(Calendar.YEAR);

                if(filterMonth == month && filterYear == year)
                {
                    result.add(new SimpleDateFormat("MMM dd").format(calEvent.getEventDate()) + "  " + calEvent.getEventDescription() );
                }
            }
            Collections.sort(result);
        }

        if(result.size() == 0)
        {
            result.add("No events exists for this month");
        }
        return result;
    }

    private CalendarEvent createEvent(String eventDate, String eventDesc)
    {
        try
        {
            return new CalendarEvent(new SimpleDateFormat("MM/dd/yyyy").parse(eventDate), eventDesc);
        }
        catch(ParseException pe)
        {

        }
        return null;
    }

    private void loadCalendarEvents(Context applicationContext, CompactCalendarView compactCalendar)
    {
        // Initialize list only one time
        if(calendarEvents != null && calendarEvents.size() > 0)
        {
            return;
        }

        calendarEvents = new ArrayList<>();

        calendarEvents.add(createEvent("07/18/2019", " -FBLA-PBL Advisers’ Training, Wesley Chapel"));
        calendarEvents.add(createEvent("07/19/2019", " -FBLA-PBL Advisers’ Training, Wesley Chapel"));
        calendarEvents.add(createEvent("07/20/2019", " -FBLA-PBL Board of Directors Meeting, Wesley Chapel"));
        calendarEvents.add(createEvent("07/21/2019", " -FBLA-PBL Board of Directors Meeting, Wesley Chapel"));
        calendarEvents.add(createEvent("09/30/2019", " -Receipt deadline for articles for the fall issue of Florida Communicator"));
        calendarEvents.add(createEvent("10/07/2019", " -Receipt deadline for State Fall Conference Registration"));
        calendarEvents.add(createEvent("10/20/2019", " -State and national initial dues deadline, to be eligible for Gold Seal Award"));
        calendarEvents.add(createEvent("11/08/2019", " -State Fall Leadership Conference, Championsgate"));
        calendarEvents.add(createEvent("11/09/2019", " -State Fall Leadership Conference, Championsgate"));
        calendarEvents.add(createEvent("11/10/2019", " -State Fall Leadership Conference, Championsgate"));
        calendarEvents.add(createEvent("11/09/2019", " -Board of Directors Meeting"));
        calendarEvents.add(createEvent("11/15/2019", " -American Enterprise Day"));
        calendarEvents.add(createEvent("11/15/2019", " -FBLA District Directors must have district test orders to State Adviser if Competition is in December\""));
        calendarEvents.add(createEvent("11/30/2019", " -Receipt deadline for articles for the winter issue of Florida Communicator"));
        calendarEvents.add(createEvent("12/04/2019", " -FBLA District Directors must have district test orders to State Adviser if competition is in January or February"));
        calendarEvents.add(createEvent("12/15/2019", " -FBLA state and national dues must be postmarked, first-class mail, to be eligible for district, state, and national competition"));



        calendarEvents.add(createEvent("01/01/2020", "-Deadline for receipt of intent letters/resumes to run for national office"));
        calendarEvents.add(createEvent("01/25/2020",  "-FBLA-PBL Board of Directors Meeting, TBA"));
        calendarEvents.add(createEvent("01/26/2020",  "-FBLA-PBL Board of Directors Meeting, TBA"));
        calendarEvents.add(createEvent("01/30/2020",  "-Receipt deadline for articles for the spring issue of Florida Communicator"));

        calendarEvents.add(createEvent("02/02/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/02/2020",  "-Tallahassee Trip for State FBLA and PBL Officers"));
        calendarEvents.add(createEvent("02/03/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/03/2020",  "-Tallahassee Trip for State FBLA and PBL Officers"));
        calendarEvents.add(createEvent("02/04/2020",  "-Tallahassee Trip for State FBLA and PBL Officers"));
        calendarEvents.add(createEvent("02/04/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/05/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/06/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/07/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/08/2020",  "-FBLA/PBL WEEK"));
        calendarEvents.add(createEvent("02/12/2020", " -FBLA received date for State Conference registration/hotel reservations/pre-judged materials"));
        calendarEvents.add(createEvent("02/15/2020", " -PBL State/National dues postmark deadline to be eligible for State Competition"));
        calendarEvents.add(createEvent("03/12/2020", " -FBLA State Leadership Conference, Hilton Orlando, Orlando"));
        calendarEvents.add(createEvent("03/13/2020", " -FBLA State Leadership Conference, Hilton Orlando, Orlando"));
        calendarEvents.add(createEvent("03/14/2020", " -FBLA State Leadership Conference, Hilton Orlando, Orlando"));
        calendarEvents.add(createEvent("03/15/2020", " -FBLA State Leadership Conference, Hilton Orlando, Orlando"));
        calendarEvents.add(createEvent("03/26/2020", " -PBL Sate Leadership Conference, Doubletree SeaWorld, Orlando"));
        calendarEvents.add(createEvent("03/27/2020", " -PBL Sate Leadership Conference, Doubletree SeaWorld, Orlando"));
        calendarEvents.add(createEvent("03/29/2020", " -PBL Sate Leadership Conference, Doubletree SeaWorld, Orlando"));
        calendarEvents.add(createEvent("04/25/2020", " -FBLA-PBL Pre-NLCs, TBA"));
        calendarEvents.add(createEvent("05/09/2020", " -FBLA-PBL Pre-NLCs, TBA"));
        calendarEvents.add(createEvent("06/24/2020", " -PBL National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("06/25/2020", " -PBL National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("06/26/2020", " -PBL National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("06/27/2020", " -PBL National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("06/29/2020", " -FBLA National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("06/30/2020", " -FBLA National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("07/01/2020", " -FBLA National Leadership Conference, Salt Lake City, UT"));
        calendarEvents.add(createEvent("08/02/2020", " -FBLA National Leadership Conference, Salt Lake City, UT"));


        // Add the events to the Calendar
        for(CalendarEvent calEvent : calendarEvents)
        {
            final Event event = new Event(Color.WHITE, calEvent.getEventDate().getTime(), calEvent.getEventDescription());
            compactCalendar.addEvent(event);
        }
    }

}