package kinghigh.fbla;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialogFragment;

public class ContactUs extends AppCompatDialogFragment {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(getActivity());
        builder.setTitle("Contact Methods")
                .setMessage("Contact us via our Edsby page (FBLA) or by asking a leadership member/Ms. Mosely. You can contact Ms. Mosely digitally via Edsby messaging or emailing her at deborah.mosely@sdhc.k12.fl.us")
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        return builder.create();
    }
}
