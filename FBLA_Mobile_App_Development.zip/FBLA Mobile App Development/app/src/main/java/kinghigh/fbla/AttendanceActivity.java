package kinghigh.fbla;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


public class AttendanceActivity extends AppCompatActivity {
    ArrayList<String> presentMembers = new ArrayList<>();
    private Button signout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        signout = (Button) findViewById(R.id.Signout);

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

        ListView names = findViewById(R.id.attendance);
        names.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        final String[] items = {
                "Ahbab Abeer",
                "Aashi Agrawal",
                "Rahul Ainpudi",
                "Mansi Akkannappa",
                "Aaryan Anand",
                "Jason Andreacchio",
                "Ananya Annamraju",
                "Aishwarya Antochen",
                "Harsh Bagdy",
                "Arpan Bagui",
                "Ashita Banda",
                "Palak Bhargav",
                "Ansh Bhatt",
                "Tanvir Bhuiyan",
                "Caden Boholst",
                "Jing Cao",
                "Jasmine Cave",
                "Prudhvi Chalasani",
                "Srikar Chandaluri",
                "Sophia Chen",
                "Sveta Chintakayala",
                "Om Chovatiya",
                "Isabella Concas",
                "Rehan Contractor",
                "James Cross",
                "Aaditya Daga",
                "Rahul Danda",
                "Joanna Desamour",
                "Anoushka Dhau",
                "Phu Doan",
                "Srinivasa Edara",
                "Michael Erathedath",
                "Lily Farzaneh",
                "Jesse Flores",
                "Elric Ford",
                "Satya Ghiassi",
                "Arko Ghosh",
                "Tushar Gona",
                "Sriharsha Grandhi",
                "Caitlin Guiang",
                "Mihir Gulati",
                "Arisha Haque",
                "Faizan Haque",
                "Zayn Haque",
                "Katelynn Hartanto",
                "Nusheen Immen",
                "Philvin Jaimon",
                "Samyak Jain",
                "Taikhoom Janoowalla",
                "Michelle Jayaraj",
                "Huzefa Johar",
                "Nathan Kallarackal",
                "Arjan Kang",
                "Varun Kanneganti",
                "Rishi Karpur",
                "Jonathan Karthaka",
                "Yewon Kee",
                "Isha Khan",
                "Nitya Kodali",
                "Shreyas Koduvayur",
                "Savith Kolipaka",
                "Mary Kommareddy",
                "Sriya Kommineni",
                "Amulya Kompella",
                "Sanat Konda",
                "Shivanshu Kumar",
                "Aishani Lahiri",
                "Leo Lam",
                "Samantha Law",
                "Kyeongeun Lee",
                "Darren Leong",
                "Dylan Leong",
                "William Li",
                "Zainab Lokhandwala",
                "Eden Luo",
                "Ian Macmartin",
                "Nihar Maddina",
                "Rijul Mandayam",
                "Anish Mandlem",
                "Serena Maner",
                "Harold Mciver",
                "Khegan Meyers",
                "Aditi Mishra",
                "Ishita Mishra",
                "Nikhil Mishra",
                "Jash Modi",
                "Justin Moore",
                "Mosley",
                "Ameya Mujumdar",
                "Rohit Nair",
                "Ritvik Nallapati",
                "Sanjana Nallapati",
                "Chibeze Oguejiofor",
                "Clara Oh",
                "Joseph Palathinkal",
                "Saaketh Palli",
                "Varun Pandey",
                "Parth Parikh",
                "Arth Patel",
                "Astha Patel",
                "Kalee Patel",
                "Krisha Patel",
                "Medha Patel",
                "Mit Patel",
                "Riya Patel",
                "Shivani Patel",
                "Siya Patel",
                "Anya Patidar",
                "David Peng",
                "Angel Peter",
                "Amy Pham",
                "Isabelle Pham",
                "Sebastian Porras",
                "Aarush Prasad",
                "Ashwini Prasanna",
                "Janani Prasanna",
                "Siyona Praveen",
                "Anshul Raghuvanshi",
                "Harshika Raghuvanshi",
                "Nishtha Rajani",
                "Isha Ratani",
                "Abhinav Ravipati",
                "Victor Roberts",
                "Jacob Rodriguez",
                "Lamar Rogers",
                "Eman Sadig",
                "Seren Sahin",
                "Shrika Senthil",
                "Aaryan Sharma",
                "Aashna Sharma",
                "Suvan Sharma",
                "Shruti Shivan",
                "Aditi Singh",
                "Annika Sinha",
                "Isabella Socci",
                "Aaryan Srivastava",
                "Haresh Subramanian",
                "Ashwatha Suresh",
                "Vrithi Takkalapalli",
                "Rahul Tatineni",
                "Anish Thalakola",
                "Manogna Thota",
                "Kelly Tian",
                "Aarush Tripathi",
                "David Tu",
                "Akash Tummala",
                "Ashvin Tyagi",
                "Shreya Venkataperumal",
                "Rahul Vijay",
                "Satvik Vippatoori",
                "Ajay Viswanathan",
                "Uma Vogeti",
                "Sean Wang",
                "Elizabeth Wielatz",
                "Na'Zariel Williams",
                "Justin Yang",
                "Nikhil Yealuru",
                "Nitin Yealuru",
                "Srija Yerram",
                "Asrith Yerramesetty",
                "Melody Zhang",
                "Ye Zhang"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.rowlayout, R.id.txt_lan, items);
        names.setAdapter(adapter);
        names.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((TextView) view).getText().toString();
                if (presentMembers.contains(selectedItem)) {
                    presentMembers.remove(selectedItem);
                } else
                    presentMembers.add(selectedItem);
            }
        });
    }

    public void showAbsentMembers(View view){
        String items = "";
        for(String item:presentMembers){
            if(items=="")
                items=item;
            else
                items+=", " +item;
            }
        Toast.makeText(this, "Absent Members: \n"+items, Toast.LENGTH_LONG).show();
        }

        public void openMainActivity(){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }

}


