package kinghigh.fbla;

import java.util.Date;

public class CalendarEvent {
    private Date eventDate;
    private String eventDescription;

    public CalendarEvent(Date date,String desc)
    {
        this.eventDate = date;
        this.eventDescription = desc;
    }
    public Date getEventDate()
    {
        return eventDate;
    }

    public void setEventDate(Date eventDate)
    {
        this.eventDate = eventDate;
    }

    public String getEventDescription()
    {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription)
    {
        this.eventDescription = eventDescription;
    }
}